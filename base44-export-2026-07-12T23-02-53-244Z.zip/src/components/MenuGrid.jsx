import React from 'react';
import { Link } from 'react-router-dom';
import { Icons } from '@/lib/icons';

const menuItems = [
  { label: 'آزمون جامع', icon: 'exam', path: '/comprehensive', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400' },
  { label: 'تاریخچه', icon: 'history', path: '/history', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
  { label: 'تایمر', icon: 'timer', path: '/timer', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400' },
  { label: 'کرنومتر', icon: 'stopwatch', path: '/stopwatch', color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  { label: 'دستاوردها', icon: 'trophy', path: '/achievements', color: 'bg-rose-500/10 text-rose-600 dark:text-rose-400' },
  { label: 'تنظیمات', icon: 'settings', path: '/settings', color: 'bg-slate-500/10 text-slate-600 dark:text-slate-400' },
];

export default function MenuGrid() {
  return (
    <div className="grid grid-cols-3 gap-3">
      {menuItems.map(item => {
        const Icon = Icons[item.icon];
        return (
          <Link
            key={item.path}
            to={item.path}
            className="bg-card rounded-2xl border p-4 flex flex-col items-center gap-2.5 hover:shadow-md transition-all active:scale-95"
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.color}`}>
              <Icon className="w-6 h-6" />
            </div>
            <span className="text-sm font-medium text-center">{item.label}</span>
          </Link>
        );
      })}
    </div>
  );
}