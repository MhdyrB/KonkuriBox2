import React, { useState, useEffect } from 'react';

const GIST_URL = 'https://api.github.com/gists/YOUR_GIST_ID'; // Replace with actual gist ID

export default function AnnouncementBar() {
  const [message, setMessage] = useState(null);
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    if (!online) return;
    // For now show a placeholder. User can configure their own gist URL.
    // fetch(GIST_URL)
    //   .then(r => r.json())
    //   .then(data => {
    //     const file = Object.values(data.files)[0];
    //     setMessage(file.content);
    //   })
    //   .catch(() => {});
  }, [online]);

  return (
    <footer className="mt-8 py-4 text-center text-sm text-muted-foreground border-t">
      {message && online && (
        <p className="mb-2 text-foreground bg-primary/5 rounded-lg p-3 text-sm">{message}</p>
      )}
      <p>ساخته شده با 💚 - نسخهٔ ۲</p>
    </footer>
  );
}