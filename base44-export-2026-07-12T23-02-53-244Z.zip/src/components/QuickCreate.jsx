import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Icons } from '@/lib/icons';
import { generateId, toPersianNum } from '@/lib/examUtils';
import { storageSet } from '@/lib/storage';

export default function QuickCreate() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [questionCount, setQuestionCount] = useState('');
  const [timeMinutes, setTimeMinutes] = useState('');
  const [negativeMarking, setNegativeMarking] = useState(true);
  const [advanced, setAdvanced] = useState(false);
  const [optionCount, setOptionCount] = useState('4');
  const [optionReversed, setOptionReversed] = useState(false);
  const [startNumber, setStartNumber] = useState('1');
  const [orderType, setOrderType] = useState('sequential');
  const [customOrder, setCustomOrder] = useState('');
  const [perQuestionTime, setPerQuestionTime] = useState('');
  const [mandatory, setMandatory] = useState(false);

  const handleStart = async () => {
    const count = parseInt(questionCount);
    if (!count || count < 1) return;

    const exam = {
      id: generateId(),
      name: name || 'پاسخبرگ بدون نام',
      type: 'quick',
      questionCount: count,
      timeSeconds: timeMinutes ? parseInt(timeMinutes) * 60 : null,
      perQuestionTimeSeconds: perQuestionTime ? parseInt(perQuestionTime) * 60 : null,
      negativeMarking,
      optionCount: parseInt(optionCount),
      optionReversed,
      startNumber: parseInt(startNumber) || 1,
      orderType,
      customOrder: orderType === 'custom' ? customOrder : '',
      mandatory,
      answers: {},
      correctAnswers: {},
      phase: 'answer', // answer | correct | analyze
      createdAt: new Date().toISOString(),
      timerStartedAt: null,
      timeRemaining: timeMinutes ? parseInt(timeMinutes) * 60 : null,
      subjects: null,
    };

    await storageSet('kb_active_exam', exam);
    navigate('/exam');
  };

  return (
    <div className="bg-card rounded-2xl border p-5 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Icons.zap className="w-5 h-5 text-primary" />
        <h2 className="font-heading font-bold text-lg">ساخت سریع</h2>
      </div>

      <div className="space-y-3">
        <div>
          <Label className="text-sm text-muted-foreground mb-1.5 block">نام آزمون (اختیاری)</Label>
          <Input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="مثلاً: ریاضی فصل ۳"
            className="text-right"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-sm text-muted-foreground mb-1.5 block">تعداد سؤالات *</Label>
            <Input
              type="number"
              value={questionCount}
              onChange={e => setQuestionCount(e.target.value)}
              placeholder="مثلاً: ۲۰"
              min="1"
              className="text-right"
            />
          </div>
          <div>
            <Label className="text-sm text-muted-foreground mb-1.5 block">زمان (دقیقه)</Label>
            <Input
              type="number"
              value={timeMinutes}
              onChange={e => setTimeMinutes(e.target.value)}
              placeholder="اختیاری"
              min="1"
              className="text-right"
            />
          </div>
        </div>

        <div className="flex items-center justify-between py-2 px-1">
          <Label className="text-sm">نمره منفی</Label>
          <Switch checked={negativeMarking} onCheckedChange={setNegativeMarking} />
        </div>

        <Collapsible open={advanced} onOpenChange={setAdvanced}>
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors w-full py-1">
              <Icons.chevronDown className={`w-4 h-4 transition-transform ${advanced ? 'rotate-180' : ''}`} />
              تنظیمات پیشرفته
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="space-y-3 pt-3 border-t mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">تعداد گزینهها</Label>
                <Select value={optionCount} onValueChange={setOptionCount}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">۲ گزینه</SelectItem>
                    <SelectItem value="3">۳ گزینه</SelectItem>
                    <SelectItem value="4">۴ گزینه</SelectItem>
                    <SelectItem value="5">۵ گزینه</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">شماره شروع</Label>
                <Input
                  type="number"
                  value={startNumber}
                  onChange={e => setStartNumber(e.target.value)}
                  min="1"
                  className="text-right"
                />
              </div>
            </div>

            <div className="flex items-center justify-between py-1 px-1">
              <Label className="text-sm">ترتیب معکوس گزینهها</Label>
              <Switch checked={optionReversed} onCheckedChange={setOptionReversed} />
            </div>

            <div>
              <Label className="text-sm text-muted-foreground mb-1.5 block">ترتیب سؤالات</Label>
              <Select value={orderType} onValueChange={setOrderType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential">یکی یکی (ترتیبی)</SelectItem>
                  <SelectItem value="skip1">یکی در میان</SelectItem>
                  <SelectItem value="skip2">دو تا در میان</SelectItem>
                  <SelectItem value="custom">ترتیب دلخواه</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {orderType === 'custom' && (
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">شماره سؤالات (با ویرگول)</Label>
                <Input
                  value={customOrder}
                  onChange={e => setCustomOrder(e.target.value)}
                  placeholder="مثلاً: 1,3,8,12"
                  className="text-left ltr"
                  dir="ltr"
                />
              </div>
            )}

            <div>
              <Label className="text-sm text-muted-foreground mb-1.5 block">زمان هر سؤال (دقیقه)</Label>
              <Input
                type="number"
                value={perQuestionTime}
                onChange={e => setPerQuestionTime(e.target.value)}
                placeholder="اختیاری"
                min="0.5"
                step="0.5"
                className="text-right"
              />
            </div>

            <div className="flex items-center justify-between py-1 px-1">
              <Label className="text-sm">پاسخ اجباری</Label>
              <Switch checked={mandatory} onCheckedChange={setMandatory} />
            </div>
          </CollapsibleContent>
        </Collapsible>

        <Button
          onClick={handleStart}
          disabled={!questionCount || parseInt(questionCount) < 1}
          className="w-full h-11 text-base font-bold mt-2 rounded-xl"
        >
          شروع آزمون
        </Button>
      </div>
    </div>
  );
}