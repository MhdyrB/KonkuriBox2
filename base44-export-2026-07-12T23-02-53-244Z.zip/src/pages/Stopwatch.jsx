import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Icons } from '@/lib/icons';
import { formatTimeMs, toPersianNum } from '@/lib/examUtils';
import { useStorage } from '@/lib/useStorage';

export default function Stopwatch() {
  const navigate = useNavigate();
  const [swState, setSwState] = useStorage('kb_stopwatch', {
    elapsed: 0,
    running: false,
    startedAt: null,
    laps: [],
  });
  const [display, setDisplay] = useState(0);
  const intervalRef = useRef(null);

  const getCurrentElapsed = useCallback(() => {
    if (!swState.running || !swState.startedAt) return swState.elapsed;
    return swState.elapsed + (Date.now() - swState.startedAt);
  }, [swState]);

  useEffect(() => {
    setDisplay(getCurrentElapsed());

    if (swState.running) {
      intervalRef.current = setInterval(() => {
        setDisplay(getCurrentElapsed());
      }, 30);
    }
    return () => clearInterval(intervalRef.current);
  }, [swState.running, swState.startedAt]);

  const handleStart = () => {
    setSwState(prev => ({ ...prev, running: true, startedAt: Date.now() }));
  };

  const handlePause = () => {
    const elapsed = getCurrentElapsed();
    setSwState(prev => ({ ...prev, running: false, elapsed, startedAt: null }));
    setDisplay(elapsed);
  };

  const handleReset = () => {
    clearInterval(intervalRef.current);
    setSwState({ elapsed: 0, running: false, startedAt: null, laps: [] });
    setDisplay(0);
  };

  const handleLap = () => {
    const elapsed = getCurrentElapsed();
    setSwState(prev => ({
      ...prev,
      laps: [...prev.laps, elapsed],
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-8">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg">
            <Icons.arrowRight className="w-5 h-5" />
          </button>
          <h1 className="font-heading font-bold text-xl">کرنومتر</h1>
        </div>

        <div className="flex flex-col items-center">
          <div className="text-5xl font-mono font-bold tabular-nums mb-8 text-primary">
            {formatTimeMs(display)}
          </div>

          <div className="flex items-center gap-3 mb-8">
            {swState.running ? (
              <Button onClick={handlePause} size="lg" variant="outline" className="w-14 h-14 rounded-full p-0">
                <Icons.pause className="w-6 h-6" />
              </Button>
            ) : (
              <Button onClick={handleStart} size="lg" className="w-14 h-14 rounded-full p-0">
                <Icons.play className="w-6 h-6" />
              </Button>
            )}
            {swState.running && (
              <Button onClick={handleLap} size="lg" variant="outline" className="w-14 h-14 rounded-full p-0">
                <Icons.flag className="w-5 h-5" />
              </Button>
            )}
            {(swState.elapsed > 0 || swState.laps.length > 0) && (
              <Button onClick={handleReset} size="lg" variant="ghost" className="w-14 h-14 rounded-full p-0 text-muted-foreground">
                <Icons.reset className="w-5 h-5" />
              </Button>
            )}
          </div>

          {/* Laps */}
          {swState.laps.length > 0 && (
            <div className="w-full max-w-xs">
              <h3 className="font-bold text-sm mb-2">لپها</h3>
              <div className="space-y-1">
                {swState.laps.map((lap, i) => {
                  const prev = i > 0 ? swState.laps[i - 1] : 0;
                  const diff = lap - prev;
                  return (
                    <div key={i} className="flex items-center justify-between bg-muted/50 rounded-lg px-3 py-2 text-sm">
                      <span className="text-muted-foreground">لپ {toPersianNum(i + 1)}</span>
                      <div className="flex gap-4">
                        <span className="text-xs text-muted-foreground">{formatTimeMs(diff)}</span>
                        <span className="font-mono font-bold">{formatTimeMs(lap)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}