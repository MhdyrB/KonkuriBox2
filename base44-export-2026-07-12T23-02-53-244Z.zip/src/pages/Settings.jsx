import React, { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Icons } from '@/lib/icons';
import { useTheme } from '@/lib/theme';
import { storageGetAll, storageSet } from '@/lib/storage';
import { useToast } from '@/components/ui/use-toast';

export default function Settings() {
  const navigate = useNavigate();
  const { theme, setTheme, fontSize, setFontSize } = useTheme();
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const handleExport = async () => {
    const data = await storageGetAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `konkuri-box-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'خروجی گرفته شد', description: 'فایل پشتیبان دانلود شد.' });
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const data = JSON.parse(text);
    for (const [key, value] of Object.entries(data)) {
      await storageSet(key, value);
    }
    toast({ title: 'وارد شد', description: 'دادهها با موفقیت وارد شدند. صفحه را رفرش کنید.' });
    e.target.value = '';
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg">
            <Icons.arrowRight className="w-5 h-5" />
          </button>
          <h1 className="font-heading font-bold text-xl">تنظیمات</h1>
        </div>

        <div className="space-y-4">
          {/* Theme */}
          <div className="bg-card border rounded-2xl p-5">
            <h3 className="font-bold text-base mb-3 flex items-center gap-2">
              <Icons.sun className="w-4 h-4" />
              پوسته
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'light', label: 'روشن', icon: Icons.sun },
                { value: 'dark', label: 'تاریک', icon: Icons.moon },
                { value: 'auto', label: 'خودکار', icon: Icons.settings },
              ].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setTheme(opt.value)}
                  className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1.5 ${
                    theme === opt.value ? 'border-primary bg-primary/5' : 'border-transparent bg-muted/50'
                  }`}
                >
                  <opt.icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div className="bg-card border rounded-2xl p-5">
            <Label className="font-bold text-base mb-3 block">اندازه متن</Label>
            <Select value={fontSize} onValueChange={setFontSize}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="sm">کوچک</SelectItem>
                <SelectItem value="base">معمولی</SelectItem>
                <SelectItem value="lg">بزرگ</SelectItem>
                <SelectItem value="xl">خیلی بزرگ</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Import/Export */}
          <div className="bg-card border rounded-2xl p-5">
            <h3 className="font-bold text-base mb-3 flex items-center gap-2">
              <Icons.download className="w-4 h-4" />
              پشتیبانگیری
            </h3>
            <div className="flex gap-2">
              <Button onClick={handleExport} variant="outline" className="flex-1 rounded-xl h-11">
                <Icons.download className="w-4 h-4 ml-2" />
                خروجی (Export)
              </Button>
              <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="flex-1 rounded-xl h-11">
                <Icons.upload className="w-4 h-4 ml-2" />
                ورودی (Import)
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImport}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}