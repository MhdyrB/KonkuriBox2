import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Icons } from '@/lib/icons';
import { generateId } from '@/lib/examUtils';
import { storageSet } from '@/lib/storage';

export default function ComprehensiveExam() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [negativeMarking, setNegativeMarking] = useState(true);
  const [optionCount, setOptionCount] = useState('4');
  const [optionReversed, setOptionReversed] = useState(false);
  const [mandatory, setMandatory] = useState(false);
  const [timeMode, setTimeMode] = useState('total'); // total | perSubject
  const [totalTime, setTotalTime] = useState('');
  const [subjects, setSubjects] = useState([
    { name: '', from: '', to: '', time: '' }
  ]);

  const addSubject = () => {
    const lastTo = subjects.length > 0 ? parseInt(subjects[subjects.length - 1].to) || 0 : 0;
    setSubjects([...subjects, { name: '', from: String(lastTo + 1), to: '', time: '' }]);
  };

  const removeSubject = (i) => {
    if (subjects.length <= 1) return;
    setSubjects(subjects.filter((_, idx) => idx !== i));
  };

  const updateSubject = (i, field, value) => {
    const updated = [...subjects];
    updated[i] = { ...updated[i], [field]: value };
    setSubjects(updated);
  };

  const totalQuestions = subjects.reduce((sum, s) => {
    const from = parseInt(s.from) || 0;
    const to = parseInt(s.to) || 0;
    return sum + Math.max(0, to - from + 1);
  }, 0);

  const handleStart = async () => {
    if (totalQuestions < 1) return;
    const validSubjects = subjects.filter(s => s.name && s.from && s.to);
    if (validSubjects.length === 0) return;

    const totalTimeSeconds = timeMode === 'total' && totalTime ? parseInt(totalTime) * 60 : null;

    const exam = {
      id: generateId(),
      name: name || 'آزمون جامع',
      type: 'comprehensive',
      questionCount: totalQuestions,
      timeSeconds: totalTimeSeconds,
      perQuestionTimeSeconds: null,
      negativeMarking,
      optionCount: parseInt(optionCount),
      optionReversed,
      startNumber: parseInt(validSubjects[0].from) || 1,
      orderType: 'sequential',
      customOrder: '',
      mandatory,
      answers: {},
      correctAnswers: {},
      phase: 'answer',
      createdAt: new Date().toISOString(),
      timerStartedAt: null,
      timeRemaining: totalTimeSeconds,
      subjects: validSubjects.map(s => ({
        name: s.name,
        from: parseInt(s.from),
        to: parseInt(s.to),
        timeSeconds: timeMode === 'perSubject' && s.time ? parseInt(s.time) * 60 : null,
      })),
    };

    await storageSet('kb_active_exam', exam);
    navigate('/exam');
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center gap-2 mb-6">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg transition-colors">
            <Icons.arrowRight className="w-5 h-5" />
          </button>
          <h1 className="font-heading font-bold text-xl">آزمون جامع</h1>
        </div>

        <div className="space-y-4">
          <div className="bg-card rounded-2xl border p-5 space-y-3">
            <div>
              <Label className="text-sm text-muted-foreground mb-1.5 block">نام آزمون</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="مثلاً: آزمون جامع شماره ۱" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">تعداد گزینهها</Label>
                <Select value={optionCount} onValueChange={setOptionCount}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">۲ گزینه</SelectItem>
                    <SelectItem value="3">۳ گزینه</SelectItem>
                    <SelectItem value="4">۴ گزینه</SelectItem>
                    <SelectItem value="5">۵ گزینه</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">نوع زمان</Label>
                <Select value={timeMode} onValueChange={setTimeMode}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="total">زمان تجمیعی</SelectItem>
                    <SelectItem value="perSubject">هر درس جدا</SelectItem>
                    <SelectItem value="none">بدون زمان</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {timeMode === 'total' && (
              <div>
                <Label className="text-sm text-muted-foreground mb-1.5 block">زمان کل (دقیقه)</Label>
                <Input type="number" value={totalTime} onChange={e => setTotalTime(e.target.value)} min="1" />
              </div>
            )}

            <div className="flex items-center justify-between py-1">
              <Label className="text-sm">نمره منفی</Label>
              <Switch checked={negativeMarking} onCheckedChange={setNegativeMarking} />
            </div>
            <div className="flex items-center justify-between py-1">
              <Label className="text-sm">ترتیب معکوس گزینهها</Label>
              <Switch checked={optionReversed} onCheckedChange={setOptionReversed} />
            </div>
            <div className="flex items-center justify-between py-1">
              <Label className="text-sm">پاسخ اجباری</Label>
              <Switch checked={mandatory} onCheckedChange={setMandatory} />
            </div>
          </div>

          {/* Subjects */}
          <div className="bg-card rounded-2xl border p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base">دروس</h3>
              <Button variant="outline" size="sm" onClick={addSubject} className="h-8 text-xs rounded-lg">
                <Icons.plus className="w-3.5 h-3.5 ml-1" />
                افزودن درس
              </Button>
            </div>

            <div className="space-y-3">
              {subjects.map((sub, i) => (
                <div key={i} className="bg-muted/50 rounded-xl p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <Input
                      value={sub.name}
                      onChange={e => updateSubject(i, 'name', e.target.value)}
                      placeholder="نام درس"
                      className="flex-1"
                    />
                    {subjects.length > 1 && (
                      <button onClick={() => removeSubject(i)} className="p-1.5 text-muted-foreground hover:text-destructive transition-colors">
                        <Icons.trash className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      value={sub.from}
                      onChange={e => updateSubject(i, 'from', e.target.value)}
                      placeholder="از سؤال"
                      min="1"
                    />
                    <Input
                      type="number"
                      value={sub.to}
                      onChange={e => updateSubject(i, 'to', e.target.value)}
                      placeholder="تا سؤال"
                      min="1"
                    />
                  </div>
                  {timeMode === 'perSubject' && (
                    <Input
                      type="number"
                      value={sub.time}
                      onChange={e => updateSubject(i, 'time', e.target.value)}
                      placeholder="زمان (دقیقه)"
                      min="1"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          <Button
            onClick={handleStart}
            disabled={totalQuestions < 1 || !subjects.some(s => s.name && s.from && s.to)}
            className="w-full h-11 text-base font-bold rounded-xl"
          >
            شروع آزمون ({totalQuestions > 0 ? `${totalQuestions} سؤال` : ''})
          </Button>
        </div>
      </div>
    </div>
  );
}