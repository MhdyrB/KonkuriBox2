import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import QuickCreate from '@/components/QuickCreate';
import MenuGrid from '@/components/MenuGrid';
import AnnouncementBar from '@/components/AnnouncementBar';
import { storageGet } from '@/lib/storage';
import { useStorage } from '@/lib/useStorage';
import { Icons } from '@/lib/icons';
import { toPersianNum } from '@/lib/examUtils';

export default function Home() {
  const navigate = useNavigate();
  const [streak] = useStorage('kb_streak', 0);
  const [hasActive, setHasActive] = useState(false);

  useEffect(() => {
    storageGet('kb_active_exam').then(exam => {
      if (exam && exam.phase !== 'done') setHasActive(true);
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-heading font-bold text-2xl text-primary">کنکوریباکس</h1>
            <p className="text-sm text-muted-foreground mt-0.5">پاسخبرگ هوشمند</p>
          </div>
          {streak > 0 && (
            <div className="flex items-center gap-1.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-full px-3 py-1.5">
              <Icons.flame className="w-4 h-4" />
              <span className="text-sm font-bold">{toPersianNum(streak)}</span>
            </div>
          )}
        </div>

        {/* Active Exam Banner */}
        {hasActive && (
          <button
            onClick={() => navigate('/exam')}
            className="w-full mb-4 bg-primary/10 border border-primary/20 rounded-xl p-3 flex items-center justify-between hover:bg-primary/15 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Icons.sheet className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">آزمون فعال دارید</span>
            </div>
            <span className="text-sm text-primary font-bold">ادامه</span>
          </button>
        )}

        {/* Quick Create */}
        <QuickCreate />

        {/* Menu */}
        <div className="mt-6">
          <h2 className="font-heading font-bold text-base mb-3 px-1">منو</h2>
          <MenuGrid />
        </div>

        {/* Footer */}
        <AnnouncementBar />
      </div>
    </div>
  );
}