import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Icons } from '@/lib/icons';
import { formatTime, toPersianNum } from '@/lib/examUtils';
import { useStorage } from '@/lib/useStorage';

export default function Timer() {
  const navigate = useNavigate();
  const [timerState, setTimerState] = useStorage('kb_timer', {
    totalSeconds: 0,
    remaining: 0,
    running: false,
    startedAt: null,
  });
  const [minutes, setMinutes] = useState('');
  const [seconds, setSeconds] = useState('');
  const [display, setDisplay] = useState(0);
  const intervalRef = useRef(null);

  const isConfigured = timerState.totalSeconds > 0;
  const isRunning = timerState.running;

  // Calculate current remaining based on when timer was started
  const getCurrentRemaining = useCallback(() => {
    if (!timerState.running || !timerState.startedAt) return timerState.remaining;
    const elapsed = Math.floor((Date.now() - timerState.startedAt) / 1000);
    return Math.max(0, timerState.remaining - elapsed);
  }, [timerState]);

  useEffect(() => {
    setDisplay(getCurrentRemaining());

    if (timerState.running) {
      intervalRef.current = setInterval(() => {
        const remaining = getCurrentRemaining();
        setDisplay(remaining);
        if (remaining <= 0) {
          clearInterval(intervalRef.current);
          setTimerState(prev => ({ ...prev, running: false, remaining: 0, startedAt: null }));
          // Play notification sound
          try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            osc.frequency.value = 800;
            osc.connect(ctx.destination);
            osc.start();
            setTimeout(() => osc.stop(), 500);
          } catch {}
        }
      }, 100);
    }

    return () => clearInterval(intervalRef.current);
  }, [timerState.running, timerState.startedAt]);

  const handleSet = () => {
    const totalSecs = (parseInt(minutes) || 0) * 60 + (parseInt(seconds) || 0);
    if (totalSecs <= 0) return;
    setTimerState({ totalSeconds: totalSecs, remaining: totalSecs, running: false, startedAt: null });
    setDisplay(totalSecs);
  };

  const handleStart = () => {
    const remaining = display > 0 ? display : timerState.remaining;
    setTimerState(prev => ({ ...prev, remaining, running: true, startedAt: Date.now() }));
  };

  const handlePause = () => {
    const remaining = getCurrentRemaining();
    setTimerState(prev => ({ ...prev, remaining, running: false, startedAt: null }));
    setDisplay(remaining);
  };

  const handleReset = () => {
    clearInterval(intervalRef.current);
    setTimerState(prev => ({ ...prev, remaining: prev.totalSeconds, running: false, startedAt: null }));
    setDisplay(timerState.totalSeconds);
  };

  const handleClear = () => {
    clearInterval(intervalRef.current);
    setTimerState({ totalSeconds: 0, remaining: 0, running: false, startedAt: null });
    setDisplay(0);
    setMinutes('');
    setSeconds('');
  };

  const progress = timerState.totalSeconds > 0 ? (display / timerState.totalSeconds) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-8">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg">
            <Icons.arrowRight className="w-5 h-5" />
          </button>
          <h1 className="font-heading font-bold text-xl">تایمر</h1>
        </div>

        <div className="flex flex-col items-center">
          {/* Circular progress */}
          <div className="relative w-64 h-64 mb-8">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
              <circle
                cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--primary))"
                strokeWidth="4" strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                className="transition-all duration-200"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-4xl font-mono font-bold tabular-nums">{formatTime(display)}</span>
            </div>
          </div>

          {/* Set time */}
          {!isConfigured && (
            <div className="flex items-end gap-2 mb-6 w-full max-w-xs">
              <div className="flex-1">
                <label className="text-xs text-muted-foreground mb-1 block">دقیقه</label>
                <Input type="number" value={minutes} onChange={e => setMinutes(e.target.value)} min="0" className="text-center" />
              </div>
              <div className="flex-1">
                <label className="text-xs text-muted-foreground mb-1 block">ثانیه</label>
                <Input type="number" value={seconds} onChange={e => setSeconds(e.target.value)} min="0" max="59" className="text-center" />
              </div>
              <Button onClick={handleSet} className="h-10 rounded-xl">تنظیم</Button>
            </div>
          )}

          {/* Controls */}
          {isConfigured && (
            <div className="flex items-center gap-3">
              {isRunning ? (
                <Button onClick={handlePause} size="lg" variant="outline" className="w-14 h-14 rounded-full p-0">
                  <Icons.pause className="w-6 h-6" />
                </Button>
              ) : (
                <Button onClick={handleStart} size="lg" className="w-14 h-14 rounded-full p-0">
                  <Icons.play className="w-6 h-6" />
                </Button>
              )}
              <Button onClick={handleReset} size="lg" variant="outline" className="w-14 h-14 rounded-full p-0">
                <Icons.reset className="w-6 h-6" />
              </Button>
              <Button onClick={handleClear} size="lg" variant="ghost" className="w-14 h-14 rounded-full p-0 text-muted-foreground">
                <Icons.x className="w-5 h-5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}