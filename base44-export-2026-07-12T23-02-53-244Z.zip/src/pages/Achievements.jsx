import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icons } from '@/lib/icons';
import { toPersianNum } from '@/lib/examUtils';
import { storageGet } from '@/lib/storage';

const achievementDefs = [
  { id: 'first_exam', title: 'اولین آزمون', desc: 'اولین آزمون خود را انجام دهید', icon: '🎯', condition: (s) => s.totalExams >= 1 },
  { id: 'five_exams', title: '۵ آزمون', desc: '۵ آزمون انجام دهید', icon: '⭐', condition: (s) => s.totalExams >= 5 },
  { id: 'ten_exams', title: '۱۰ آزمون', desc: '۱۰ آزمون انجام دهید', icon: '🏅', condition: (s) => s.totalExams >= 10 },
  { id: 'twenty_exams', title: '۲۰ آزمون', desc: '۲۰ آزمون انجام دهید', icon: '🏆', condition: (s) => s.totalExams >= 20 },
  { id: 'fifty_exams', title: '۵۰ آزمون', desc: '۵۰ آزمون انجام دهید', icon: '👑', condition: (s) => s.totalExams >= 50 },
  { id: 'streak_3', title: 'استریک ۳ روزه', desc: '۳ روز متوالی مطالعه کنید', icon: '🔥', condition: (s) => s.streak >= 3 },
  { id: 'streak_7', title: 'استریک ۷ روزه', desc: '۷ روز متوالی مطالعه کنید', icon: '💪', condition: (s) => s.streak >= 7 },
  { id: 'streak_14', title: 'استریک ۱۴ روزه', desc: '۱۴ روز متوالی مطالعه کنید', icon: '🚀', condition: (s) => s.streak >= 14 },
  { id: 'streak_30', title: 'استریک ۳۰ روزه', desc: '۳۰ روز متوالی مطالعه کنید', icon: '💎', condition: (s) => s.streak >= 30 },
];

export default function Achievements() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ totalExams: 0, streak: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      storageGet('kb_totalExams'),
      storageGet('kb_streak'),
    ]).then(([total, streak]) => {
      setStats({ totalExams: total || 0, streak: streak || 0 });
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const unlockedCount = achievementDefs.filter(a => a.condition(stats)).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg">
            <Icons.arrowRight className="w-5 h-5" />
          </button>
          <h1 className="font-heading font-bold text-xl">دستاوردها</h1>
        </div>

        {/* Stats overview */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-card border rounded-xl p-3 text-center">
            <div className="text-2xl font-bold text-primary">{toPersianNum(stats.totalExams)}</div>
            <div className="text-xs text-muted-foreground mt-1">آزمون</div>
          </div>
          <div className="bg-card border rounded-xl p-3 text-center">
            <div className="text-2xl font-bold text-amber-500 flex items-center justify-center gap-1">
              <Icons.flame className="w-5 h-5" />
              {toPersianNum(stats.streak)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">استریک</div>
          </div>
          <div className="bg-card border rounded-xl p-3 text-center">
            <div className="text-2xl font-bold text-emerald-500">{toPersianNum(unlockedCount)}</div>
            <div className="text-xs text-muted-foreground mt-1">باز شده</div>
          </div>
        </div>

        {/* Achievement list */}
        <div className="space-y-2">
          {achievementDefs.map(ach => {
            const unlocked = ach.condition(stats);
            return (
              <div
                key={ach.id}
                className={`bg-card border rounded-xl p-4 flex items-center gap-3 transition-opacity ${
                  unlocked ? '' : 'opacity-40'
                }`}
              >
                <div className="text-2xl">{ach.icon}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-sm">{ach.title}</h3>
                  <p className="text-xs text-muted-foreground">{ach.desc}</p>
                </div>
                {unlocked && (
                  <Icons.check className="w-5 h-5 text-emerald-500" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}