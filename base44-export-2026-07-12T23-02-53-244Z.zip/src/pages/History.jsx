import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { storageGet, storageSet } from '@/lib/storage';
import { Icons } from '@/lib/icons';
import { toPersianNum, calculateScore } from '@/lib/examUtils';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from '@/components/ui/alert-dialog';

export default function History() {
  const navigate = useNavigate();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    storageGet('kb_history').then(h => {
      setHistory(h || []);
      setLoading(false);
    });
  }, []);

  const deleteRecord = async (id) => {
    const updated = history.filter(h => h.id !== id);
    setHistory(updated);
    await storageSet('kb_history', updated);
  };

  const clearAll = async () => {
    setHistory([]);
    await storageSet('kb_history', []);
  };

  const viewRecord = async (record) => {
    const exam = { ...record, phase: 'analyze' };
    await storageSet('kb_active_exam', exam);
    navigate('/exam');
  };

  const types = [...new Set(history.map(h => h.type))];
  const filtered = filter === 'all' ? history : history.filter(h => h.type === filter);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg">
              <Icons.arrowRight className="w-5 h-5" />
            </button>
            <h1 className="font-heading font-bold text-xl">تاریخچه</h1>
          </div>
          {history.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-destructive text-xs">حذف همه</Button>
              </AlertDialogTrigger>
              <AlertDialogContent dir="rtl">
                <AlertDialogHeader>
                  <AlertDialogTitle>حذف تمام تاریخچه؟</AlertDialogTitle>
                  <AlertDialogDescription>این عمل قابل بازگشت نیست.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>انصراف</AlertDialogCancel>
                  <AlertDialogAction onClick={clearAll} className="bg-destructive text-destructive-foreground">حذف</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {/* Filter */}
        {types.length > 1 && (
          <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium shrink-0 transition-colors ${
                filter === 'all' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
              }`}
            >همه</button>
            {types.map(t => (
              <button
                key={t}
                onClick={() => setFilter(t)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium shrink-0 transition-colors ${
                  filter === t ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}
              >{t === 'quick' ? 'سریع' : 'جامع'}</button>
            ))}
          </div>
        )}

        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <Icons.history className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">هنوز آزمونی ثبت نشده</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(record => {
              const stats = calculateScore(record.answers, record.correctAnswers, record.negativeMarking, record.optionCount);
              return (
                <div key={record.id} className="bg-card border rounded-xl p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-sm">{record.name}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">{record.completedAtPersian}</p>
                    </div>
                    <div className="text-left">
                      <span className="text-lg font-bold text-primary">{toPersianNum(stats.percentage.toFixed(1))}٪</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                    <span>درست: {toPersianNum(stats.correct)}</span>
                    <span>غلط: {toPersianNum(stats.wrong)}</span>
                    <span>نزده: {toPersianNum(stats.blank)}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-3">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${Math.max(0, stats.percentage)}%` }} />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => viewRecord(record)} className="text-xs flex-1 rounded-lg">
                      مشاهده تحلیل
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-destructive text-xs rounded-lg">
                          <Icons.trash className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent dir="rtl">
                        <AlertDialogHeader>
                          <AlertDialogTitle>حذف این آزمون؟</AlertDialogTitle>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>انصراف</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteRecord(record.id)} className="bg-destructive text-destructive-foreground">حذف</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}