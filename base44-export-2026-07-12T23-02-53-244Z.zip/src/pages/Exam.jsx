import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { storageGet, storageSet } from '@/lib/storage';
import { generateQuestionOrder, toPersianNum, generateId, getPersianDate } from '@/lib/examUtils';
import { Icons } from '@/lib/icons';
import ExamTimer from '@/components/exam/ExamTimer';
import AnswerSheet from '@/components/exam/AnswerSheet';
import AnalysisView from '@/components/exam/AnalysisView';

export default function Exam() {
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    storageGet('kb_active_exam').then(e => {
      if (!e) {
        navigate('/');
        return;
      }
      // Set timer start if not set
      if (e.timeSeconds && !e.timerStartedAt && e.phase === 'answer') {
        e.timerStartedAt = new Date().toISOString();
      }
      setExam(e);
      setLoading(false);
    });
  }, []);

  const saveExam = useCallback(async (updated) => {
    setExam(updated);
    await storageSet('kb_active_exam', updated);
  }, []);

  const questions = React.useMemo(() => {
    if (!exam) return [];
    if (exam.subjects && exam.subjects.length > 0) {
      // For comprehensive exams, build question list from subjects
      const qs = [];
      exam.subjects.forEach(sub => {
        for (let i = sub.from; i <= sub.to; i++) qs.push(i);
      });
      return qs;
    }
    return generateQuestionOrder(exam.questionCount, exam.startNumber, exam.orderType, exam.customOrder);
  }, [exam]);

  const handleAnswer = useCallback((qNum, value) => {
    if (!exam) return;
    const newAnswers = { ...exam.answers };
    if (value === null) {
      delete newAnswers[qNum];
    } else {
      newAnswers[qNum] = value;
    }
    saveExam({ ...exam, answers: newAnswers });
  }, [exam, saveExam]);

  const handleCorrectAnswer = useCallback((qNum, value) => {
    if (!exam) return;
    const newCorrect = { ...exam.correctAnswers };
    if (value === null) {
      delete newCorrect[qNum];
    } else {
      newCorrect[qNum] = value;
    }
    saveExam({ ...exam, correctAnswers: newCorrect });
  }, [exam, saveExam]);

  const goToPhase = async (phase) => {
    if (phase === 'correct' && exam.mandatory) {
      const unanswered = questions.filter(q => !exam.answers[q]);
      if (unanswered.length > 0) {
        alert(`${toPersianNum(unanswered.length)} سؤال بدون پاسخ مانده. ابتدا همه سؤالات را پاسخ دهید.`);
        return;
      }
    }
    const updated = { ...exam, phase };
    if (phase === 'analyze') {
      // Save to history
      const history = await storageGet('kb_history') || [];
      const record = {
        ...updated,
        completedAt: new Date().toISOString(),
        completedAtPersian: getPersianDate(),
      };
      history.unshift(record);
      await storageSet('kb_history', history);

      // Update streak
      const today = new Date().toDateString();
      const lastStudy = await storageGet('kb_lastStudyDate');
      const streak = await storageGet('kb_streak') || 0;
      if (lastStudy !== today) {
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        const newStreak = lastStudy === yesterday ? streak + 1 : 1;
        await storageSet('kb_streak', newStreak);
        await storageSet('kb_lastStudyDate', today);
      }

      // Update achievements
      const totalExams = (await storageGet('kb_totalExams') || 0) + 1;
      await storageSet('kb_totalExams', totalExams);
    }
    saveExam(updated);
  };

  const handleFinish = async () => {
    await storageSet('kb_active_exam', null);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!exam) return null;

  const answeredCount = Object.keys(exam.phase === 'correct' ? exam.correctAnswers : exam.answers).length;
  const phaseLabels = { answer: 'پاسخدهی', correct: 'تصحیح', analyze: 'تحلیل' };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-lg mx-auto px-4 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/')} className="p-2 hover:bg-muted rounded-lg transition-colors">
              <Icons.arrowRight className="w-5 h-5" />
            </button>
            <div>
              <h1 className="font-heading font-bold text-base">{exam.name}</h1>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{phaseLabels[exam.phase]}</span>
                <span>•</span>
                <span>{toPersianNum(answeredCount)}/{toPersianNum(questions.length)}</span>
              </div>
            </div>
          </div>
          {exam.phase === 'answer' && exam.timeSeconds && (
            <ExamTimer
              exam={exam}
              onExamUpdate={saveExam}
              onTimeUp={() => goToPhase('correct')}
            />
          )}
        </div>

        {/* Phase indicator */}
        <div className="flex gap-1 mb-4">
          {['answer', 'correct', 'analyze'].map((p, i) => (
            <div
              key={p}
              className={`flex-1 h-1.5 rounded-full transition-colors ${
                exam.phase === p ? 'bg-primary' : 
                ['answer', 'correct', 'analyze'].indexOf(exam.phase) > i ? 'bg-primary/30' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        {/* Content */}
        {exam.phase === 'answer' && (
          <div>
            <p className="text-sm text-muted-foreground mb-3">
              گزینههای خود را انتخاب کنید. برای حذف، دوباره روی گزینه کلیک کنید.
            </p>
            <AnswerSheet
              questions={questions}
              answers={exam.answers}
              onAnswer={handleAnswer}
              optionCount={exam.optionCount}
              optionReversed={exam.optionReversed}
              mandatory={exam.mandatory}
            />
            <div className="flex gap-2 mt-4">
              <Button onClick={() => goToPhase('correct')} className="flex-1 h-11 rounded-xl font-bold">
                مرحله تصحیح
              </Button>
            </div>
          </div>
        )}

        {exam.phase === 'correct' && (
          <div>
            <p className="text-sm text-muted-foreground mb-3">
              کلید پاسخ صحیح را وارد کنید.
            </p>
            <AnswerSheet
              questions={questions}
              answers={exam.correctAnswers}
              onAnswer={handleCorrectAnswer}
              optionCount={exam.optionCount}
              optionReversed={exam.optionReversed}
            />
            <div className="flex gap-2 mt-4">
              <Button variant="outline" onClick={() => goToPhase('answer')} className="h-11 rounded-xl px-6">
                بازگشت
              </Button>
              <Button
                onClick={() => goToPhase('analyze')}
                disabled={Object.keys(exam.correctAnswers).length === 0}
                className="flex-1 h-11 rounded-xl font-bold"
              >
                تحلیل نتایج
              </Button>
            </div>
          </div>
        )}

        {exam.phase === 'analyze' && (
          <div>
            <AnalysisView exam={exam} />
            
            {/* Detailed answer sheet */}
            <div className="mt-6">
              <h3 className="font-bold text-base mb-3">مقایسه پاسخها</h3>
              <AnswerSheet
                questions={questions}
                answers={exam.answers}
                optionCount={exam.optionCount}
                optionReversed={exam.optionReversed}
                readOnly
                correctAnswers={exam.correctAnswers}
              />
            </div>

            <div className="flex gap-2 mt-6">
              <Button variant="outline" onClick={() => goToPhase('correct')} className="h-11 rounded-xl px-6">
                بازگشت
              </Button>
              <Button onClick={handleFinish} className="flex-1 h-11 rounded-xl font-bold">
                بازگشت به خانه
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}